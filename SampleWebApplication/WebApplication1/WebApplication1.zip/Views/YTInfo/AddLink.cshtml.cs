using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.YTInfo
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
